const express = require('express');
const path = require('path');
const { connect } = require('./db'); // Database connection

const app = express();
const port = process.env.PORT || 3000;

// Set the view engine to EJS
app.set('view engine', 'ejs');

// Serve static files from the 'public' directory
app.use(express.static(path.join(__dirname, 'public')));

// Define a route for the root URL to render the home page
app.get('/home', (req, res) => {
    res.render('home');
});


// Middleware for parsing URL-encoded data and JSON data
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Define a route for the root URL to render the login page
app.get('/', (req, res) => {
    res.render('login', { error: req.query.error }); // Pass the 'error' variable to the view
});

// Handle form submission for user authentication
app.post('/login', async (req, res) => {
    const { username, password } = req.body;

    // Get the database instance using the connect function from db.js
    const db = await connect();

    // Perform authentication here (e.g., check credentials against the database)
    const userCollection = db.collection('users');
    const user = await userCollection.findOne({ username, password });

    if (user) {
        // Successful login - redirect to the Business Contacts List View
        res.redirect('/business-contacts');
    } else {
        // Failed login - redirect back to the Login View with an error message
        res.redirect('/?error=1');
    }
});

// Route for rendering the Business Contacts List View
app.get('/business-contacts', async (req, res) => {
    const db = await connect();
    const userCollection = db.collection('users');

    // Fetch and sort contacts alphabetically by Contact Name
    const contacts = await userCollection.find({}).toArray();
    contacts.sort((a, b) => a.contactName.localeCompare(b.contactName));

    res.render('business-contacts', { contacts });
});

// Route for rendering the Update View
app.get('/update/:id', (req, res) => {
    const contactId = req.params.id;
    res.render('update', { contactId });
});

app.post('/update/:id', async (req, res) => {
    const contactId = req.params.id;
    const { contactName, contactNumber, email } = req.body; // Get updated data from the form

    const db = await connect();
    const userCollection = db.collection('users');

    // Update the contact document based on its _id
    await userCollection.updateOne(
        { _id: ObjectId(contactId) },
        {
            $set: {
                contactName: contactName,
                contactNumber: contactNumber,
                email: email
                // Add other fields as needed
            }
        }
    );

    // Redirect back to the Business Contacts List View
    res.redirect('/business-contacts');
});

// Route for handling contact deletion
app.get('/delete/:id', async (req, res) => {
    const contactId = req.params.id;
    const db = await connect();
    const userCollection = db.collection('users');

    // Create an ObjectId instance
    const objectId = new ObjectId(contactId);

    // Delete the contact document based on its _id
    await userCollection.deleteOne({ _id: objectId });

    // Redirect back to the Business Contacts List View
    res.redirect('/business-contacts');
});

app.post('/confirm-delete/:id', async (req, res) => {
    const contactId = req.params.id;
    const db = await connect();
    const userCollection = db.collection('users');

    // Delete the contact document based on its _id
    await userCollection.deleteOne({ _id: ObjectId(contactId) });

    // Redirect back to the Business Contacts List View
    res.redirect('/business-contacts');
});

// Define routes for other pages (About, Projects, Services, Contact)
app.get('/about', (req, res) => {
    res.render('about');
});

app.get('/projects', (req, res) => {
    res.render('projects');
});

app.get('/services', (req, res) => {
    res.render('services');
});

app.get('/contact', (req, res) => {
    res.render('contact');
});

// Start the server
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
