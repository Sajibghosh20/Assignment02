const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
  res.render('home');
});

router.get('/about', (req, res) => {
  res.render('about');
});

// Repeat for other pages
app.get('/login', (req, res) => {
  res.render('login');
});

module.exports = router;
