// db.js

const { MongoClient } = require('mongodb');

const uri = 'mongodb://localhost:27017/project';

const client = new MongoClient(uri, { useUnifiedTopology: true });

async function connect() {
  try {
    await client.connect();
    console.log('Connected to the database');
    return client.db();
  } catch (err) {
    console.error('Database connection error:', err);
    throw err;
  }
}

module.exports = { connect };
